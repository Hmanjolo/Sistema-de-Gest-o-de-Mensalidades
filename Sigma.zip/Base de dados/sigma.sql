-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 07-Ago-2020 às 11:41
-- Versão do servidor: 10.4.11-MariaDB
-- versão do PHP: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `sigma`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `aluno`
--

CREATE TABLE `aluno` (
  `nr_aluno` int(11) NOT NULL,
  `tipo_documento` varchar(25) NOT NULL,
  `nr_documento` varchar(15) NOT NULL,
  `local_de_emissao` varchar(50) NOT NULL,
  `nome_aluno` varchar(45) NOT NULL,
  `apelido_aluno` varchar(40) NOT NULL,
  `nacionalidade_aluno` varchar(35) NOT NULL,
  `naturalidade_aluno` varchar(50) NOT NULL,
  `data_nascimento_aluno` date NOT NULL,
  `validade_documento_inicial_aluno` date NOT NULL,
  `validade_documento_final_aluno` date DEFAULT NULL,
  `sexo_aluno` varchar(20) NOT NULL,
  `bairro` varchar(50) NOT NULL,
  `quarteirao` varchar(6) NOT NULL,
  `casa` smallint(6) NOT NULL,
  `rua_avenida` varchar(100) NOT NULL,
  `telefone` int(9) NOT NULL,
  `telefone_alternativo` int(9) DEFAULT NULL,
  `nome_do_pai` varchar(120) NOT NULL,
  `nome_da_mae` varchar(120) NOT NULL,
  `email` varchar(100) NOT NULL,
  `url_foto` varchar(700) NOT NULL,
  `data_criado_aluno` datetime DEFAULT current_timestamp(),
  `data_modificado_aluno` datetime DEFAULT current_timestamp(),
  `criado_por` int(11) DEFAULT NULL,
  `modificado_por` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `classe`
--

CREATE TABLE `classe` (
  `nr_classe` int(11) NOT NULL,
  `nome_classe` varchar(50) NOT NULL,
  `data_criado_classe` datetime DEFAULT current_timestamp(),
  `data_modificado_turma` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `criado_por` int(11) DEFAULT NULL,
  `modificado_por` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `conf_mensalidades`
--

CREATE TABLE `conf_mensalidades` (
  `id` int(11) NOT NULL,
  `nr_aluno` int(11) NOT NULL,
  `mes` varchar(12) COLLATE utf32_bin NOT NULL,
  `recibo` bigint(20) NOT NULL,
  `ano` year(4) NOT NULL,
  `data_deposito` date NOT NULL,
  `criado_por` int(11) NOT NULL,
  `data_criacao` datetime NOT NULL DEFAULT current_timestamp(),
  `modificado_por` int(11) NOT NULL,
  `data_modificacao` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

-- --------------------------------------------------------

--
-- Estrutura da tabela `inscricao_detalhes`
--

CREATE TABLE `inscricao_detalhes` (
  `id` int(11) NOT NULL,
  `recibo` int(11) NOT NULL,
  `nr_aluno` int(11) NOT NULL,
  `valor_inscricao` int(11) NOT NULL DEFAULT 1200,
  `valor_mensalidade` int(11) NOT NULL DEFAULT 525,
  `data_deposito` date NOT NULL,
  `criado_por` int(11) NOT NULL,
  `data_criacao` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `matricula`
--

CREATE TABLE `matricula` (
  `nr_matricula` int(11) NOT NULL,
  `nr_aluno` int(11) NOT NULL,
  `nr_turma` int(11) NOT NULL,
  `nr_pagamento` int(11) NOT NULL,
  `data_criado_pagamento` datetime DEFAULT current_timestamp(),
  `data_modificado_pagamento` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `criado_por` int(11) DEFAULT NULL,
  `modificado_por` int(11) DEFAULT NULL,
  `ano` year(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `mensalidades`
--

CREATE TABLE `mensalidades` (
  `ID` int(11) NOT NULL,
  `nr_aluno` int(11) NOT NULL,
  `Fev` char(1) DEFAULT NULL,
  `Mar` char(1) DEFAULT NULL,
  `Abr` char(1) DEFAULT NULL,
  `Mai` char(1) DEFAULT NULL,
  `Jun` char(1) DEFAULT NULL,
  `Jul` char(1) DEFAULT NULL,
  `Ago` char(1) DEFAULT NULL,
  `Sete` char(1) DEFAULT NULL,
  `Outu` char(1) DEFAULT NULL,
  `Nov` char(1) DEFAULT NULL,
  `Ano` year(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tabela_nivel_acesso`
--

CREATE TABLE `tabela_nivel_acesso` (
  `id_nivel_acesso` int(11) NOT NULL,
  `nome_nivel_acesso` varchar(50) NOT NULL,
  `data_criacao` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tabela_nivel_acesso`
--

INSERT INTO `tabela_nivel_acesso` (`id_nivel_acesso`, `nome_nivel_acesso`, `data_criacao`) VALUES
(1, 'Administrador  full  ', '2017-08-24 00:00:00'),
(2, 'Administrador', '2020-03-27 19:46:08'),
(3, 'Area Administrativa ', '2017-08-24 00:00:00'),
(4, 'Secretaria', '2018-03-06 00:00:00'),
(5, 'Professor', '2017-08-24 00:00:00'),
(6, 'Aluno', '2017-08-24 00:00:00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tabela_usuarios`
--

CREATE TABLE `tabela_usuarios` (
  `id_usuario` int(11) NOT NULL,
  `f_key` bigint(20) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `nome` varchar(200) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `estado` varchar(10) NOT NULL DEFAULT 'Activo',
  `id_nivel_acesso` int(11) NOT NULL,
  `data_criacao` datetime NOT NULL DEFAULT current_timestamp(),
  `criado_por` varchar(50) NOT NULL,
  `data_modificacao` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modificado_por` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tabela_usuarios`
--

INSERT INTO `tabela_usuarios` (`id_usuario`, `f_key`, `usuario`, `nome`, `senha`, `estado`, `id_nivel_acesso`, `data_criacao`, `criado_por`, `data_modificacao`, `modificado_por`) VALUES
(11, 1000000017, 'Helena', 'Helena Rafael', '81dc9bdb52d04dc20036dbd8313ed055', 'Activo', 1, '2020-04-26 21:07:51', '1', '2020-08-07 11:37:06', '1'),
(24, 1000000017, 'Admin', 'Administrador', '21232f297a57a5a743894a0e4a801fc3', 'Activo', 1, '2020-04-26 21:07:51', '1', '2020-08-07 11:37:06', '1');

-- --------------------------------------------------------

--
-- Estrutura da tabela `turma`
--

CREATE TABLE `turma` (
  `nr_turma` int(11) NOT NULL,
  `nome_turma` varchar(15) NOT NULL,
  `duracao_turma` varchar(15) NOT NULL,
  `classe_turma` varchar(15) NOT NULL,
  `formato_turma` varchar(50) NOT NULL,
  `numero_sessoes_formato` tinyint(2) NOT NULL,
  `data_criado_turma` date DEFAULT NULL,
  `data_modificado_turma` date DEFAULT NULL,
  `criado_por` int(11) DEFAULT NULL,
  `modificado_por` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `aluno`
--
ALTER TABLE `aluno`
  ADD PRIMARY KEY (`nr_aluno`),
  ADD UNIQUE KEY `nr_documento` (`nr_documento`);

--
-- Índices para tabela `classe`
--
ALTER TABLE `classe`
  ADD PRIMARY KEY (`nr_classe`);

--
-- Índices para tabela `conf_mensalidades`
--
ALTER TABLE `conf_mensalidades`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `recibo` (`recibo`);

--
-- Índices para tabela `inscricao_detalhes`
--
ALTER TABLE `inscricao_detalhes`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `matricula`
--
ALTER TABLE `matricula`
  ADD PRIMARY KEY (`nr_matricula`);

--
-- Índices para tabela `mensalidades`
--
ALTER TABLE `mensalidades`
  ADD PRIMARY KEY (`ID`);

--
-- Índices para tabela `tabela_nivel_acesso`
--
ALTER TABLE `tabela_nivel_acesso`
  ADD PRIMARY KEY (`id_nivel_acesso`);

--
-- Índices para tabela `tabela_usuarios`
--
ALTER TABLE `tabela_usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `usuario` (`usuario`);

--
-- Índices para tabela `turma`
--
ALTER TABLE `turma`
  ADD PRIMARY KEY (`nr_turma`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `aluno`
--
ALTER TABLE `aluno`
  MODIFY `nr_aluno` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `classe`
--
ALTER TABLE `classe`
  MODIFY `nr_classe` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `conf_mensalidades`
--
ALTER TABLE `conf_mensalidades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `inscricao_detalhes`
--
ALTER TABLE `inscricao_detalhes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `matricula`
--
ALTER TABLE `matricula`
  MODIFY `nr_matricula` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `mensalidades`
--
ALTER TABLE `mensalidades`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `tabela_nivel_acesso`
--
ALTER TABLE `tabela_nivel_acesso`
  MODIFY `id_nivel_acesso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `tabela_usuarios`
--
ALTER TABLE `tabela_usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT de tabela `turma`
--
ALTER TABLE `turma`
  MODIFY `nr_turma` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

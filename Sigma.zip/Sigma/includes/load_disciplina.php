<?php require_once "Class.class.php";
/*
	$q=@$_GET['q'];
	$administracao = new administracao;
	echo $administracao->listar_disciplinas($q);*/
	
	echo "<meta http-equiv='refresh' content='3'>";
?>


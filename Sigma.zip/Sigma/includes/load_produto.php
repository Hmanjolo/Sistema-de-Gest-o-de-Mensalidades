<?php require_once "Class.class.php";
	$produto = new produto;
	echo $produto->listar_produtos();
?>

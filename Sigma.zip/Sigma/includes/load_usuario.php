<?php require_once "Class.class.php";
	$usuario = new usuario;
	echo $usuario->listar_usuarios();
?>

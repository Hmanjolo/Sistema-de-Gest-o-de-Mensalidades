<?php require_once "Class.class.php";
	$fornecedor = new fornecedor;
	echo $fornecedor->listar_fornecedores();
?>

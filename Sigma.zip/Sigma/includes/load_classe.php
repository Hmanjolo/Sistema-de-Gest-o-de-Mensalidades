<?php require_once "Class.class.php";
	$administracao = new administracao;
	echo $administracao->listar_classes();
?>

